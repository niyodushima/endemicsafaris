 jQuery(document).ready(function ($) {
    jQuery("#submit_review_rating").click(function () {
        var post_id = jQuery('#'+prefix+'_post_id').val();
        var name = jQuery('#'+prefix+'_name').val();
        var email = jQuery('#'+prefix+'_email').val();
        var title = jQuery('#'+prefix+'_title').val();
        var website = jQuery('#'+prefix+'_website').val();
        var rating =  jQuery('input[name=rating]:checked').val();
        var ratingLength =  jQuery('input[name=rating]:checked').length;
        var review = jQuery('#'+prefix+'_review').val();
        var maxLength = 500;
        var error = 0;
        if(showfields['name']['show'] == 1 && showfields['name']['require'] == 1){
          // Validating Name Field blank.
          if (name.length == 0) {
            jQuery('#'+prefix+'_name').focus();
            jQuery('#fields_name').remove();
            jQuery('#'+prefix+'_name').after('<span id="fields_name" class="error">Please Enter a name.</span>');
            error = 1;
          }
        }
        if(showfields['email']['require'] == 1){
          if (email.length == 0) {
            jQuery('#fields_email').remove();
            jQuery('#'+prefix+'_email').focus();
            jQuery('#'+prefix+'_email').after('<span id="fields_email" class="error">Please Enter a Email Address.</span>');
            error = 1;
          }
          else{
            if (!validateEmail(email)) {
              jQuery('#fields_email').remove();
              jQuery('#'+prefix+'_email').after('<span id="fields_email" class="error">Invalid Email Address.</span>');
              jQuery('#'+prefix+'_email').focus();
              error = 1;
            }
          }
        }
        // Validating rating Field.
        if(ratingLength == 0){
          jQuery('#fields_rating').remove();
          jQuery('.rating-input').after('<span id="fields_rating" class="error">Please enable a rating.</span>');
          error = 1;
        }

        if (title.length == 0) {
          jQuery('#'+prefix+'_title').focus();
          jQuery('#fields_title').remove();
          jQuery('#'+prefix+'_title').after('<span id="fields_title" class="error">Please Enter a Review Title.</span>');
          error = 1;
        }else if (title.length < 8 ) {
          jQuery('#fields_title').remove();
          jQuery('#'+prefix+'_title').after('<span id="fields_title" class="error">Review Title must be 8 characters long!.</span>');
          error = 1;
        }
        if(review == ''){
          jQuery('#fields_review').remove();
          jQuery('#'+prefix+'_review').after('<span id="fields_review" class="error">Please Enter a review.</span>');
          error = 1;
        } else if (review.length < 8) {
          jQuery('#fields_review').remove();
          jQuery('#'+prefix+'_review').after('<span id="fields_review" class="error">Review text must be 10 characters long!.</span>');
          jQuery('#'+prefix+'_review').focus();            
          error = 1;
        }else if (review.length > maxLength) {
          jQuery('#fields_review').remove();
          jQuery('#'+prefix+'_review').after('<span id="fields_review" class="error">Review text length less then 500 characters.</span>');
          jQuery('#'+prefix+'_review').focus();            
          error = 1;
        }
        if(error == 1 ){
          return false;
        }

        jQuery('.loading').show();
        jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:{
               'action':'myaction',
               'post_id':post_id,
               'name':name,
               'email':email,
               'title':title,
               'website':website,
               'rating':rating,
               'review':review,
               'check_human':1,
               },
            dataType: 'JSON',
            success: function(success) {
            jQuery('.loading').hide();
            if(success.status == 'success'){
                alert(success.message);
                jQuery('#'+prefix+'_name, #'+prefix+'_email, #'+prefix+'_website, #'+prefix+'_review, #'+prefix+'_title').val('');
                jQuery( '#'+prefix+'_check_human' ).prop( "checked", false );
                jQuery( 'input[name=rating]' ).prop( "checked", false );
				jQuery('#rating_submit_form .error').remove();
            }else if(success.status == 'error'){           
                alert(success.message);

              }
          },
        });
    });

    jQuery("#load_more").click(function () {
      var row = Number(jQuery('#row').val());
      var allcount = Number(jQuery('#all').val());
      row = row + 3;
      if(row <= allcount){
        jQuery("#row").val(row);
        jQuery('.loading').show();
        jQuery.ajax({
            type:"POST",
            url: ajaxurl,
            data:{
              'action':'load_more',
              'start':row,
            },
            success: function(response) {
              jQuery('.loading').hide();
                jQuery( ".ul_reviews li" ).last().after(response); 
                var rowno = row + 3;
                if(rowno > allcount){
                  jQuery('#load_more').hide();
                  jQuery('#row').val(1);
                }
          },
        });
      }
    });
    
    jQuery("#btn_write_review").click(function() {
      jQuery('html, body').animate({
            scrollTop: jQuery("#write_review_section").offset().top
        }, 2000);
    });

});

function validateEmail(mail) {
  if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail)){
    return (true)
  } else{
    return (false)
  }
}